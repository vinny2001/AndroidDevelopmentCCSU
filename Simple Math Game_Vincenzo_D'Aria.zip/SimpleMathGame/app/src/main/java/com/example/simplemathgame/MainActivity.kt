package com.example.simplemathgame

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_main.*
import java.util.*
import android.content.Context
import android.graphics.Color
import android.view.inputmethod.InputMethodManager
import android.widget.Toast


class MainActivity : AppCompatActivity() {

    //variable declarations
    private var num1 = 0
    private var num2 = 0

    private var score = 0
    private var total = 0

    private var levelNum = 1
    private var range = 10

    //main
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        init()
    }

    //------------------Start Code Below-------------------------------

    // When answer button is clicked, it runs the function that checks the answer
    fun answerButton(view: View){
        checkAnswer("answerButton")
    }

    //When the reset button is pressed, reinitialize the app with reset score, total and a new problem
    @SuppressLint("SetTextI18n")
    fun resetButton(view: View){
        score = 0
        total = 0
        levelNum = 1
        range = 10
        findViewById<TextView>(R.id.score).text = "Score: $score / $total"
        findViewById<TextView>(R.id.responseFeedback).text =""
        init()
        val gameResetMessage = Toast.makeText(applicationContext, "Game Reset!", Toast.LENGTH_SHORT)
        gameResetMessage.show()
    }

    //Conditional function that delivers the result based on user's input
    @SuppressLint("SetTextI18n")
    private fun checkAnswer(buttonClicked: String){
        val result = num2 * num1
        val textInput = findViewById<TextView>(R.id.answer).text.toString().toIntOrNull()

        if (textInput == null) {
            val nullAnswerMessage = Toast.makeText(applicationContext, "Answer field is empty, please try again", Toast.LENGTH_SHORT)
            nullAnswerMessage.show()
            return
        }
        //Colored text that will popup after answering right or wrong
        val feedback = findViewById<TextView>(R.id.responseFeedback)

        if (textInput == result){
            feedback.text = "Correct!"
            feedback.setTextColor(Color.parseColor("#00FF00"))
            score++


        } else{
            feedback.text = "Wrong! $num1 * $num2 = $result"
            feedback.setTextColor(Color.parseColor("#FF0000"))
        }

        total++
        findViewById<TextView>(R.id.score).text = "Score: $score / $total"
        answer.hideKeyboard()
        answer.text.clear()
        init()
    }

    //Initializes app with specified settings
    //EXTRA CREDIT FUNCTIONALITY: Added 3 levels
    // * Range increases gradually as levels go on
    // * 3 Levels added for demonstration, more can be easily added

    @SuppressLint("SetTextI18n")
    private fun init(){

        //Level 1
        num1 = generateRandomNumber(range)
        num2 = generateRandomNumber(range)

        findViewById<TextView>(R.id.level).text = "Level: $levelNum"

        //Level 2
        if (score in 10..29){
            if(score == 10){
                levelNum++
            }
            range = 13

        //Level 3
        }else if(score >= 30){
            if(score == 30){
                levelNum++
            }
            range = 21
        }
        findViewById<TextView>(R.id.question).text = "What is $num1 * $num2?"
    }

    //Generates random number with a max range of 10
    private fun generateRandomNumber(range: Int): Int {
        return Random().nextInt(range)
    }

    //Function to lower keyboard after inputting answer
    private fun View.hideKeyboard() {
        val inputMethodManager = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        inputMethodManager.hideSoftInputFromWindow(windowToken, 0)
    }
}